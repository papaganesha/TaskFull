window.addEventListener("load",() =>{
    var root = document.getElementById("root")
    root.innerHTML = "<h1>Usuario não autenticado, sem acesso<h1>";
  })


  