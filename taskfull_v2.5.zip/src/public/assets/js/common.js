export function dismissable_sucess_Msg(msg){
    return `
     <div class="alert alert-success  alert-dismissible fade show" role="alert">
        <strong>Tudo Certo!</strong>${" "}${msg}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
    `
}

export function dismissable_warning_Msg(msg){
    return `
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Erro!</strong>${" "}${msg}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  `
}
